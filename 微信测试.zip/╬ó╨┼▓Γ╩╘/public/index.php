<?php
require_once dirname(__DIR__) . '/lib/boot.php';
require_once $_SERVER["SCRIPT_NAME"];
require_once 'weixin/index.php';